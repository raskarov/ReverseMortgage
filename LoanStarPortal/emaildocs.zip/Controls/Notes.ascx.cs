using System;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Web.UI.WebControls;
using LoanStar.Common;
using Telerik.WebControls;

namespace LoanStarPortal.Controls
{
    public partial class Notes : AppControl
    {
        #region Fields/Properties
        private readonly Color colorNote = Color.Yellow;
        private readonly Color colorAlert = Color.LightPink;
        private readonly Color colorEvent = Color.LightBlue;
        private readonly Color colorEmail = Color.LightGreen;

        private const string ConditionType = "Condition"; 
        private const string AlertType = "Alert";
        private const string NoteType = "Note";
        private const string EventType = "Event";
        private const string EmailType = "Email";
        private const string MESSAGEBOARDFILTER = "mbfilter";
        private const int DATESELECTION = 0;
        private const int DETAILSSELECTION = 2;
        private const int ITEMSELECTION = 1;

        public int DisplayLevelSelection
        {
            get
            {
                int res = 1;
                Object o = Session["DisplayLevelSelection"];
                if(o!=null)
                {
                    try
                    {
                        res = int.Parse(o.ToString());
                    }
                    catch
                    {
                    }
                }
                return res;
            }
            set { Session["DisplayLevelSelection"] = value; }
        }
        public  string DivQuickNoteId
        {

            get { return divQuickNote.ClientID;}
        }
        private int MortgageID
        {
            get
            {
                return Convert.ToInt32(Session[Constants.MortgageID]);
            }
        }
        public int? ConditionID
        {
            set
            {
                ViewState["mbConditionID"] = value;
            }
            get
            {
                if (ViewState["mbConditionID"] == null)
                    return null;
                else
                    return Convert.ToInt32(ViewState["mbConditionID"]);
            }
        }
        public bool IsFirstLoad
        {
            get
            {
                Object o = ViewState["FirstLoadNotes"];
                bool res = true;
                if (o != null)
                {
                    try
                    {
                        res = bool.Parse(o.ToString());
                    }
                    catch
                    {
                    }
                }
                return res;
            }
            set
            {
                ViewState["FirstLoadNotes"] = value;
            }
        }
        public MessageBoardFilter CurrentFilter
        {
            get 
            {
                MessageBoardFilter res = Session[MESSAGEBOARDFILTER] as MessageBoardFilter;
                if (res == null)
                {
                    res = new MessageBoardFilter();
                    Session[MESSAGEBOARDFILTER] = res;
                }
                return res;
            }
            set
            {
                Session[MESSAGEBOARDFILTER] = value;
            }
        }
        #endregion

        protected void Page_Load(object sender, EventArgs e)
        {
            CurrentFilter.MinutesOffset = CurrentUser.GetMinutesOffset();
            GetDisplayLevelSelection();
            BindDisplayLevel();
            CurrentFilter.SetMortgage(MortgageID);
            SetCheckBoxes();
            BindMessageBoard();
        }
        private void BindDisplayLevel()
        {
            ddlDisplayLevel.Items.Clear();
            ddlDisplayLevel.Items.Add(new ListItem("Dates", DATESELECTION.ToString()));
            ddlDisplayLevel.Items.Add(new ListItem("Items", ITEMSELECTION.ToString()));
            ddlDisplayLevel.Items.Add(new ListItem("Detail",DETAILSSELECTION.ToString()));
            ddlDisplayLevel.SelectedValue = DisplayLevelSelection.ToString();
            ddlDisplayLevel.Attributes.Add("onchange","DisplayLevelChanged(this);");
        }
        private void GetDisplayLevelSelection()
        {
            string tmp = GetPostedValue(ddlDisplayLevel.ID);
            if(!String.IsNullOrEmpty(tmp))
            {
                try
                {
                    DisplayLevelSelection = int.Parse(tmp);
                }
                catch
                {
                }
            }
        }
        private string GetPostedValue(string controlId)
        {
            string res = "";
            for (int i = 0; i < Page.Request.Form.AllKeys.Length; i++)
            {
                string s = Page.Request.Form.AllKeys[i];
                if (s.EndsWith("$" + controlId))
                {
                    res = Page.Request.Form[s];
                    break;
                }
            }
            return res;
        }
        public void BindData()
        {
            chbEvents.Visible = !(CurrentFilter.ConditionId > 0);
            BindMessageBoard();
        }
        private static void AddDateAttribute(WebControl item,string val)
        {
            item.Attributes["Date"] = val;
        }

        private void BindMessageBoard()
        {
            panelMessageBoard.Items.Clear();
            MortgageProfile mp = CurrentPage.GetMortgage(MortgageID);
            DateTime MortgageDate = mp.Created;
            CultureInfo culture = CultureInfo.InvariantCulture;

            DateTime repDate = DateTime.Now;
            int weekNum = culture.Calendar.GetWeekOfYear(repDate, CalendarWeekRule.FirstDay, DayOfWeek.Monday);
            int monthNum = repDate.Month;
            //Adding Today pane
            DataTable messList = LoadMessages(repDate);
            if (messList.Rows.Count > 0)
            {
                RadPanelItem todayPane = new RadPanelItem();
                AddDateAttribute(todayPane, "1");
                todayPane.Expanded = (DisplayLevelSelection == ITEMSELECTION) ||(DisplayLevelSelection == DETAILSSELECTION);
                todayPane.Text = String.Format("Today");
                panelMessageBoard.Items.Add(todayPane);
                FillPanelItem(todayPane, messList, false);
            }
            RadPanelItem lastWeekPane = null;

            //this gets current week
            int curWeekNum = culture.Calendar.GetWeekOfYear(repDate, CalendarWeekRule.FirstDay, DayOfWeek.Monday);

           //Adding Yesterday pane
            repDate = repDate.AddDays(-1);
            if (repDate >= MortgageDate)
            {
                messList = LoadMessages(repDate);
                if (messList.Rows.Count > 0)
                {
                    //this gets data retrieved week
                    weekNum = culture.Calendar.GetWeekOfYear(repDate, CalendarWeekRule.FirstDay, DayOfWeek.Monday);
                    if (weekNum == curWeekNum)
                    {
                        RadPanelItem yesterdayPane = new RadPanelItem();
                        yesterdayPane.Expanded = (DisplayLevelSelection == ITEMSELECTION) || (DisplayLevelSelection == DETAILSSELECTION);
                        AddDateAttribute(yesterdayPane, "1");
                        yesterdayPane.Text = String.Format("Yesterday");
                        FillPanelItem(yesterdayPane, messList, false);
                        panelMessageBoard.Items.Add(yesterdayPane);
                    }
                    else
                    {
                        lastWeekPane = new RadPanelItem("Last week");
                        lastWeekPane.Expanded = (DisplayLevelSelection == ITEMSELECTION) || (DisplayLevelSelection == DETAILSSELECTION);
                        AddDateAttribute(lastWeekPane, "1");
                        FillPanelItem(lastWeekPane, messList, true);
                        panelMessageBoard.Items.Add(lastWeekPane);
                    }
                }
            }

            //data for this week found
            if (lastWeekPane == null)
            {
                repDate = repDate.AddDays(-1);
                curWeekNum = culture.Calendar.GetWeekOfYear(repDate, CalendarWeekRule.FirstDay, DayOfWeek.Monday);

                int numAgo = 2;
                while (repDate >= MortgageDate && weekNum == curWeekNum)
                {
                    messList = LoadMessages(repDate);
                    if (messList.Rows.Count > 0)
                    {
                        RadPanelItem otherDatePane = new RadPanelItem();
                        otherDatePane.Expanded = (DisplayLevelSelection == ITEMSELECTION) || (DisplayLevelSelection == DETAILSSELECTION);
                        AddDateAttribute(otherDatePane, "1");
                        otherDatePane.Text = String.Format("{0} Days Ago", numAgo);
                        FillPanelItem(otherDatePane, messList, true);
                        panelMessageBoard.Items.Add(otherDatePane);
                    }
                    repDate = repDate.AddDays(-1);
                    numAgo++;
                    weekNum = culture.Calendar.GetWeekOfYear(repDate, CalendarWeekRule.FirstDay, DayOfWeek.Monday);
                }
            }

            //last week
            curWeekNum = weekNum;
            while (repDate >= MortgageDate && weekNum == curWeekNum)  //&& monthNum == repDate.Month
            {
                messList = LoadMessages(repDate);
                if (messList.Rows.Count > 0)
                {
                    if (lastWeekPane == null)
                    {
                        lastWeekPane = new RadPanelItem("Last week");
                        lastWeekPane.Expanded = (DisplayLevelSelection == ITEMSELECTION) || (DisplayLevelSelection == DETAILSSELECTION);
                        AddDateAttribute(lastWeekPane, "1");
                        panelMessageBoard.Items.Add(lastWeekPane);
                    }
                    FillPanelItem(lastWeekPane, messList, true);
                }
                repDate = repDate.AddDays(-1);
                weekNum = culture.Calendar.GetWeekOfYear(repDate, CalendarWeekRule.FirstDay, DayOfWeek.Monday);
            }

            //two week and more (up to month)
             curWeekNum = weekNum;
            int weekAgo = 2;
            while (repDate >= MortgageDate && monthNum == repDate.Month)
            {
                RadPanelItem otherWeekPane = new RadPanelItem();
                otherWeekPane.Expanded = (DisplayLevelSelection == ITEMSELECTION) || (DisplayLevelSelection == DETAILSSELECTION);
                AddDateAttribute(otherWeekPane, "1");
                otherWeekPane.Text = String.Format("{0} Weeks Ago", weekAgo);
                otherWeekPane.Value = String.Format("D&{0}", repDate.ToShortDateString());
                bool bAddPane = false;
                while (repDate >= MortgageDate && weekNum == curWeekNum && monthNum == repDate.Month)
                {
                    messList = LoadMessages(repDate);
                    if (messList.Rows.Count > 0)
                    {
                        FillPanelItem(otherWeekPane, messList, true);
                        if (messList.Rows.Count > 0 && otherWeekPane.Items.Count > 0) bAddPane = true;
                    }
                    repDate = repDate.AddDays(-1);
                    weekNum = culture.Calendar.GetWeekOfYear(repDate, CalendarWeekRule.FirstDay, DayOfWeek.Monday);
                }
                otherWeekPane.Value += ":" + repDate.AddDays(1).ToShortDateString();
                if (bAddPane)
                    panelMessageBoard.Items.Add(otherWeekPane);
                weekNum = curWeekNum;
                weekAgo++;
            }
            //months ago
            DateTime periodLasDate = repDate.AddDays(1).AddMonths(-5);
            int monthAgo = 1;
            while (repDate >= MortgageDate && periodLasDate <= repDate)
            {
                monthNum = repDate.Month;
                RadPanelItem otherMonthPane = new RadPanelItem();
                otherMonthPane.Expanded = (DisplayLevelSelection == ITEMSELECTION) || (DisplayLevelSelection == DETAILSSELECTION);
                AddDateAttribute(otherMonthPane, "1");
                otherMonthPane.Text = String.Format("{0} Month Ago", monthAgo);
                otherMonthPane.Value = String.Format("D&{0}", repDate.ToShortDateString());
                bool bAddPane = false;
                while (repDate >= MortgageDate && monthNum == repDate.Month && periodLasDate <= repDate)
                {
                    messList = LoadMessages(repDate);
                    if (messList.Rows.Count > 0)
                    {
                        repDate = new DateTime(repDate.Year, repDate.Month, 1).AddDays(-1);
                        FillPanelItem(otherMonthPane, messList, true);
                        if (messList.Rows.Count > 0 && otherMonthPane.Items.Count > 0) bAddPane = true;
                    }
                    repDate = repDate.AddDays(-1);
                }
                otherMonthPane.Value += ":" + repDate.AddDays(1).ToShortDateString();
                if (bAddPane)
                    panelMessageBoard.Items.Add(otherMonthPane);
                monthAgo++;
            }
            //6 months ago
            if (repDate >= MortgageDate)
            {
                RadPanelItem sixMonthPane = new RadPanelItem();
                sixMonthPane.Expanded = (DisplayLevelSelection == ITEMSELECTION) || (DisplayLevelSelection == DETAILSSELECTION);
                AddDateAttribute(sixMonthPane, "1");
                sixMonthPane.Text = "More than 6 Month Ago";
                sixMonthPane.Value = String.Format("D&{0}", repDate.ToShortDateString());
                bool bAddPane = false;
                while (repDate >= MortgageDate)
                {
                    messList = LoadMessages(repDate);
                    if (messList.Rows.Count > 0)
                    {
                        repDate = MortgageDate;
                        FillPanelItem(sixMonthPane, messList, true);
                        if (messList.Rows.Count > 0 && sixMonthPane.Items.Count > 0) bAddPane = true;
                    }
                    repDate = repDate.AddDays(-1);
                }
                sixMonthPane.Value += ":" + repDate.AddDays(1).ToShortDateString();
                if (bAddPane)
                    panelMessageBoard.Items.Add(sixMonthPane);
            }
        }
        private DataTable LoadMessages(DateTime repDate)
        {
            return new DataTable();
            //return MessageBoard.LoadMessageBoard(CurrentFilter, repDate,CurrentUser.Id);
        }

        private void FillPanelItem(IRadPanelItemContainer item, DataTable itemlist, bool NeedDate)
        {
            foreach (DataRow row in itemlist.Rows)
            {
                AddPanelItem(item, row, NeedDate);
            }                    
        }

        private void AddPanelItem(IRadPanelItemContainer item, DataRow row, bool NeedDate)
        {
            string MesType = Convert.ToString(row["MessageType"]);
            RadPanelItem newItem = new RadPanelItem();
            newItem.Expanded = DisplayLevelSelection == DETAILSSELECTION;
            string Title = Convert.ToString(row["Title"]);

            if (Title.Length > 17)
                Title = Title.Substring(0, 17) + "...";

            string imgPath = "";
            DateTime dt = DateTime.Parse(row["Created"].ToString());
            //string messageType = row["MessageType"].ToString().ToLower();
            //if(messageType == "email")
            //{
            //    dt =
            //        WebMailPro.Utils.GetMessageDateWithOffset(dt,
            //                                                  WebMailPro.Utils.GetMinutesTimesOffset(
            //                                                      CurrentUser.TimeZone));
            //}
//            string Date = (NeedDate) ? Convert.ToDateTime(row["Created"]).ToString("MM/dd/yyyy hh:mm") : Convert.ToDateTime(row["Created"]).ToString("hh:mm");
            string Date = (NeedDate) ? dt.ToString("MM/dd/yyyy hh:mm tt") : dt.ToString("hh:mm tt");
            newItem.Value = String.Format("{0}&{1}", row["ID"], row["Created"]);
            newItem.Width = Unit.Percentage(100);
            string Description="";
            if(!String.IsNullOrEmpty(Convert.ToString(row["FromMail"])))
                Description += "<p><b>From</b>: " + Convert.ToString(row["FromMail"]) + "<br />";
            if (!String.IsNullOrEmpty(Convert.ToString(row["ToMail"])))
                Description += "<b>To</b>: " + Convert.ToString(row["ToMail"]) + "<br /></p>";
            Description += Convert.ToString(row["Description"]).Replace("\n", "<br>");
            switch (MesType)
            {
                case ConditionType:
                    newItem.BackColor = colorEvent;
                    imgPath = ResolveUrl("~/Images/itask.gif");
                    break;
                case EventType:
                    newItem.BackColor = colorEvent;
                    imgPath = ResolveUrl("~/Images/ievent.gif");
                    break;
                case AlertType:
                    newItem.BackColor = colorAlert;
                    imgPath = ResolveUrl("~/Images/ialert.gif");
                    break;
                case NoteType:
                    newItem.BackColor = colorNote;
                    imgPath = ResolveUrl("~/Images/inote.gif");
                    break;
                case EmailType:
                    newItem.BackColor = colorEmail;
                    imgPath = ResolveUrl("~/Images/imailunread.gif");
                    break;
            }
            newItem.Text = String.Format("<span style='float:right;'>{3}</span><img src='{0}' border='0' />&nbsp;{1}&nbsp;&nbsp;<b>{2}</b>", imgPath, MesType, Title, Date);

            RadPanelItem ci = new RadPanelItem();
            //Panel panelGeneral = new Panel();
            Literal lblText = new Literal();
            lblText.Text = String.Format("<div style='border:none;width:99%;'><table width='100%'><tr><td width='2px'>&nbsp;</td><td style='line-height:15px;'>{0}</td></tr></table></div>", Description);
            ci.Controls.Add(lblText);
            newItem.Items.Add(ci);
            item.Items.Add(newItem);
        }
        protected void btnCreate_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(tbNote.Text))
                Condition.SaveNote(null, MortgageID, tbNote.Text, CurrentUser.Id);
            tbNote.Text = "";
            BindData();
        }
        private void SetFilter(Object sender)
        {
            CheckBox cb = sender as CheckBox;
            if (cb != null)
            {
                if (cb.ID == chbEvents.ID)
                {
                    CurrentFilter.ShowEvents = cb.Checked;
                }
                else if (cb.ID == chbNote.ID)
                {
                    CurrentFilter.ShowNotes = cb.Checked;
                }
                else if (cb.ID == chbEmail.ID)
                {
                    CurrentFilter.ShowEmails = cb.Checked;
                }
/*
                if (cb.ID == chbConditions.ID)
                {
                    CurrentFilter.ShowConditions = cb.Checked;
                }
                else if (cb.ID == chbEvents.ID)
                {
                    CurrentFilter.ShowEvents = cb.Checked;
                }
                else if (cb.ID == chbNote.ID)
                {
                    CurrentFilter.ShowNotes = cb.Checked;
                }
                else if (cb.ID == chbEmail.ID)
                {
                    CurrentFilter.ShowEmails = cb.Checked;
                }
 */ 
            }
        }
        private void SetCheckBoxes()
        {
//            chbConditions.Checked = CurrentFilter.ShowConditions;
            chbNote.Checked = CurrentFilter.ShowNotes;
            chbEmail.Checked = CurrentFilter.ShowEmails;
            chbEvents.Checked = CurrentFilter.ShowEvents;
        }
        protected void FilterChanged(object sender, EventArgs e)
        {
            SetFilter(sender);
            BindData();
        }

    }
}