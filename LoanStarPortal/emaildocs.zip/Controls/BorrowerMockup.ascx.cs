using System;
using System.Web.UI;

namespace LoanStarPortal.Controls
{
    public partial class BorrowerMockup : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}