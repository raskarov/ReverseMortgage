namespace LoanStarPortal.App_Code
{
    public class GuideLine
    {
        #region fields
        //private static DatabaseAccess db = new DatabaseAccess(AppSettings.SqlConnectionString);
        #endregion

        #region constructor
        public GuideLine()
        {
        }
        #endregion

        #region methods
        #region static methods
        #endregion
        #endregion
    }
}
